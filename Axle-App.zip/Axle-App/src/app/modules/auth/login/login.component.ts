import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  isLogin: boolean = false;
  isLoggingIn: boolean = false;
  returnUrl: string = '';

  constructor(private authService: AuthenticationService, private router: Router, private activatedRoute: ActivatedRoute) {

  }

  ngOnInit(): void {

    // var header = {
    //   headers: new HttpHeaders().set(
    //     'Authorization',
    //     'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImN0eSI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6Imd1cnByZWV0QGJlY2tlcmFsbGlhbmNlLmNvbSIsIm5iZiI6MTY4ODYxNjc5MiwiZXhwIjoxNjg4NjE3MzkyLCJpYXQiOjE2ODg2MTY3OTJ9.MwBdgCgnbZCPGQnGhu6BuNqVCTOMH1WOG4lSRAgZ_aY'
    //   ),
    // };

    // this.api.post('http://192.168.1.150/axle-api-refined-video/api/Analytics/PracticeDashboardOnload_New', {}, header).subscribe((res) => {
    //   console.log(res)
    // });


    this.returnUrl = this.activatedRoute.snapshot.queryParams['returnUrl'] || '/';
    if (this.authService.isAuthenticated) {
      this.router.navigateByUrl(this.returnUrl)
    }
  }
}
