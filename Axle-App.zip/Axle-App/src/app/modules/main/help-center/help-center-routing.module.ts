import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HelpCenterComponent } from './help-center/help-center.component';

const routes: Routes = [
  { path: 'help', component: HelpCenterComponent },
  { path: '',  pathMatch:'full', redirectTo:'help' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnalyticsRoutingModule { }
