import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PendingComponent } from './pending/pending.component';
import { VerifiedComponent } from './verified/verified.component';
import { EligibilityRoutingModule } from './eligibility-routing.module';
import { OverviewComponent } from './dashboard/overview/overview.component';
import { StatsVerificationsComponent } from './dashboard/stats-verifications/stats-verifications.component';
import { StatsPracticeComponent } from './dashboard/stats-practice/stats-practice.component';
import { StatsUnverifiedPatientsComponent } from './dashboard/stats-unverified-patients/stats-unverified-patients.component';
import { StatsEmployeesComponent } from './dashboard/stats-employees/stats-employees.component';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [
    DashboardComponent,
    PendingComponent,
    VerifiedComponent,
    OverviewComponent,
    StatsVerificationsComponent,
    StatsPracticeComponent,
    StatsUnverifiedPatientsComponent,
    StatsEmployeesComponent
  ],
  imports: [
    CommonModule,
    EligibilityRoutingModule,
    SharedModule
  ]
})
export class EligiblityModule { }
