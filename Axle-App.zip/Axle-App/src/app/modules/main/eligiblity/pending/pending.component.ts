
import { Component } from "@angular/core";
import { TreeNode } from "primeng/api";

@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.scss']
})
export class PendingComponent {
  pendingTableData: any[] = [];
  nodes: TreeNode[] = [];
  selected: any;
  isCommlogModal: boolean = false;

  openCommlogModal() {
    this.isCommlogModal = true;
    document.body.classList.add('noScroll');
  }

  closeCommlogModal() {
    this.isCommlogModal = false;
    document.body.classList.remove('noScroll');
  }
  ngOnInit() {

    this.pendingTableData = [

      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Missing Payer',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Inactive',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Error',
          benefits: '$2,500.21'
        },
        status: 'ds',

      }, {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Missing Payer',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Inactive',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Error',
          benefits: '$2,500.21'
        },
        status: 'ds',

      }, {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Missing Payer',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Inactive',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Error',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Missing Payer',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Active',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Inactive',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },
      {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Error',
          benefits: '$2,500.21'
        },
        status: 'ds',

      }, {
        patientName: 'Pedro BeckerL',
        patientNameSub: 'Smiling Teeth Clinic',
        userPic: '../../../../../assets/Pedro.png',
        apptDate: 'Feb 3, 2022 9:00 AM',
        procedure: 'D0120,D0220 (+6)',
        eligibility: {
          status: 'Error',
          benefits: '$2,500.21'
        },
        status: 'ds',

      },

    ];

    this.nodes = [

      {
        "label": 'Assigned',
      },
      {
        "label": "INS VERIFIED",
      },
      {
        "label": "Left VM",
      },
      {
        "label": "Office Verified",
      },
      {
        "label": "Previously Verified",
      },
      {
        "label": "Private Pay / DSP",
      },

      {
        "label": "Unable to Verify",

        "children": [
          {
            "label": "Appt Cancelled",
          },
          {
            "label": "HMO/DMO/DHMO",
          },
          {
            "label": "Invalid Insurance info",
          },
          {
            "label": "Medicaid Insurance",
          },
          {
            "label": "Medical Only",
          },
          {
            "label": "Missing Insurance info",
          },
          {
            "label": "No insurance provided",
          }
        ]
      }
    ];
  }

}
