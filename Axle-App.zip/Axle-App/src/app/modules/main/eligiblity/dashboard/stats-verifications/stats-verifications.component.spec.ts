import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatsVerificationsComponent } from './stats-verifications.component';

describe('StatsVerificationsComponent', () => {
  let component: StatsVerificationsComponent;
  let fixture: ComponentFixture<StatsVerificationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatsVerificationsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StatsVerificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
