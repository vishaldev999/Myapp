import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatsUnverifiedPatientsComponent } from './stats-unverified-patients.component';

describe('StatsUnverifiedPatientsComponent', () => {
  let component: StatsUnverifiedPatientsComponent;
  let fixture: ComponentFixture<StatsUnverifiedPatientsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatsUnverifiedPatientsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StatsUnverifiedPatientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
