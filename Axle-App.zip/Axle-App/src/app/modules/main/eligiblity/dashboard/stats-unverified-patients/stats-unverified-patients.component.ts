import { Component } from '@angular/core';

@Component({
  selector: 'app-stats-unverified-patients',
  templateUrl: './stats-unverified-patients.component.html',
  styleUrls: ['./stats-unverified-patients.component.scss']
})
export class StatsUnverifiedPatientsComponent {

}
