import { Component } from '@angular/core';

@Component({
  selector: 'app-stats-employees',
  templateUrl: './stats-employees.component.html',
  styleUrls: ['./stats-employees.component.scss']
})
export class StatsEmployeesComponent {
  employeesStats: any[] = [];

  ngOnInit() {

    this.employeesStats = [

      {
        shortName: 'LL',
        isShortName: false,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: true,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: true,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: false,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: false,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: true,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: true,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: false,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: false,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: true,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: true,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: false,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: false,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: true,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: true,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: false,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: false,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: true,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: true,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: false,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: false,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: true,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: true,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: false,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: false,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: true,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        shortName: 'LL',
        isShortName: true,
        fullName: 'Lois Lane',
        userPic: '../../../../../assets/Pedro.png',
        isUserPic: false,
        emailId: 'pedrobecker@meetaxle.com',
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },


    ];

  }

}
