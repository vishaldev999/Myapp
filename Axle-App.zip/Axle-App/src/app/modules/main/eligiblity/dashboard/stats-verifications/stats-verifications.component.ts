import { Component } from '@angular/core';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-stats-verifications',
  templateUrl: './stats-verifications.component.html',
  styleUrls: ['./stats-verifications.component.scss']
})
export class StatsVerificationsComponent {

  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {

    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      crosshair: {
        //width: 100,
        color: 'rgba(77,193,213,0.1)'
      },
      lineWidth: 0,
      minorGridLineWidth: 0,
      lineColor: 'transparent',
      labels: {

        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
          lineHeight: '17px'
        }
      },
    },

    yAxis: {
      gridLineColor: 'rgba(243, 244, 246, 1)',
      title: {
        text: '',
      },
      labels: {
        formatter: function (this: any) {
          return Highcharts.numberFormat(this.value, 0, ',', ',');
        },
        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
          lineHeight: '17px'
        }
      },

    },
    title: { text: '' },
    subtitle: { text: '' },
    credits: { enabled: false },

    series: [{
      showInLegend: false,
      name: 'Insuarance Verified',
      data: [500, 800, 200, 800, 300, 500, 800, 400, 800, 500, 400, 800],
      type: 'spline',
      color: '#0acadc',
      marker: {
        enabled: true,
        symbol: 'circle',
        radius: 4,
        fillColor: '#fff',
        lineColor: '#0acadc',
        lineWidth: 3,
        states: {
          hover: {
            enabled: true,
            lineColor: '#0acadc',
            lineWidth: 2,
          }

        },
      }
    },
    {
      showInLegend: false,
      name: 'Private Pay',
      data: [0, 100, 100, 0, 200, 50, 0, 200, 0, 50, 0, 0],
      type: 'spline',
      color: '#9267B4',
      marker: {
        enabled: true,
        symbol: 'circle',
        radius: 4,
        fillColor: '#fff',
        lineColor: '#9267B4',
        lineWidth: 3,
        states: {
          hover: {
            enabled: true,
            lineColor: '#9267B4',
            lineWidth: 2,
          }
        },
      }
    }, {
      showInLegend: false,
      name: 'Terminated',
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      type: 'spline',
      color: '#ff7597',
      borderWidth: 0,
      marker: {
        enabled: true,
        symbol: 'circle',
        radius: 4,
        fillColor: '#fff',
        lineColor: '#ff7597',
        lineWidth: 3,
        states: {
          hover: {
            enabled: true,
            lineColor: '#ff7597',
            lineWidth: 2,
          }
        },
      }

    }],

    tooltip: {
      shared: true,
      outside: true,
      useHTML: true,
      backgroundColor: '#fff',
      borderRadius: 10,
      positioner: function (labelWidth, _, point) {
        //console.log(labelWidth, _, point)
        return {
          x: point.plotX - 100,
          y: point.plotY - 185,
        };
      },
      formatter: function (response) {
        let tooltip = '<div class="chart_tooltip_verification">';
        tooltip += '<h4>' + this.x + ' ' + new Date().getFullYear() + '</h4>';
        tooltip += '<div class = "tooltip-content">';
        tooltip += '<div class="item"><p><b class=' + this.points?.[0].color + '></b><span>' + this.points?.[0].series.name + '</span></p><h6>' + this.points?.[0].y + '</h6></p></div><div class="item"><p><b class=' + this.points?.[1].color + '></b><span>' + this.points?.[1].series.name + '</span></p><h6>' + this.points?.[1].y + '</h6></p></div><div class="item"><p><b class=' + this.points?.[2].color + '></b><span>' + this.points?.[2].series.name + '</span></p><h6>' + this.points?.[2].y + '</h6></p></div>';
        tooltip += '</div>'
        return tooltip;
      }
    }

  }

}