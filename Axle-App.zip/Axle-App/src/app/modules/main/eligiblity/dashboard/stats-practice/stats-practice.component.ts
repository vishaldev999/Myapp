import { Component } from '@angular/core';
@Component({
  selector: 'app-stats-practice',
  templateUrl: './stats-practice.component.html',
  styleUrls: ['./stats-practice.component.scss']
})
export class StatsPracticeComponent {

  practicestats: any[] = [];
  expandStats: boolean = false;

  expendStats() {
    this.expandStats = true;
  }

  ngOnInit() {

    this.practicestats = [

      {
        practiceName: 'Practice 1',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 2',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 3',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 4',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 5',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 6',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 7',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 8',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 9',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 10',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 11',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 12',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 13',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },
      {
        practiceName: 'Practice 14',
        pAddress: "401 E Sonterra Blvd, San Antonio, TX 78258",
        totalVerified: '155',
        totalUnverified: '155',
        officeVerified: '155',
        unableVerify: '155',
        privatePay: '155',
        assigned: "155",
        unassigned: "155"
      },


    ];

  }

}
