import { Component } from '@angular/core';

@Component({
  selector: 'app-hygiene',
  templateUrl: './hygiene.component.html',
  styleUrls: ['./hygiene.component.scss']
})
export class HygieneComponent {

}
