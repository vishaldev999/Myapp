import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HygieneComponent } from './hygiene/hygiene.component';
import { PracticeComponent } from './practice/practice.component';
import { ProviderComponent } from './provider/provider.component';
import { RegionComponent } from './region/region.component';

const routes: Routes = [
  { path: 'hygiene', component: HygieneComponent },
  { path: 'practice', component: PracticeComponent },
  { path: 'provider', component: ProviderComponent },
  { path: 'region', component: RegionComponent },
  { path: '',  pathMatch:'full', redirectTo:'practice' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnalyticsRoutingModule { }
