import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsComponent } from './forms/forms.component';
import { FormsRoutingModule } from './forms-routing.module';
import { OverviewComponent } from './dashboard/overview/overview.component';
import { ReferralSourceComponent } from './dashboard/referral-source/referral-source.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { StatsPracticeComponent } from './dashboard/stats-practice/stats-practice.component';
import { FormStatusComponent } from './dashboard/form-status/form-status.component';




@NgModule({
  declarations: [
    DashboardComponent,
    FormsComponent,
    OverviewComponent,
    ReferralSourceComponent,
    StatsPracticeComponent,
    FormStatusComponent,

  ],
  imports: [
    CommonModule,
    FormsRoutingModule,
    SharedModule
  ]
})
export class FormsModule { }
