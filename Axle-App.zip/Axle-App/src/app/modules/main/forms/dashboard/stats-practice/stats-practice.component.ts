import { Component } from '@angular/core';

@Component({
  selector: 'app-stats-practice',
  templateUrl: './stats-practice.component.html',
  styleUrls: ['./stats-practice.component.scss']
})
export class StatsPracticeComponent {
  practicestats: any[] = [];

  ngOnInit() {

    this.practicestats = [
      {
        practicename: 'Practice 1',
        address: '401 E Sonterra Blvd, San Antonio, TX 78258',

        totalSent: {
          item: '850',
          delivered: '68 Not Delivered'
        },
        totalCompleted: {
          item: '800',
          patients: '602 Patients'
        },
        totalPending: {
          item: '850',
          patients: '8002 Patients'
        },
        conversionRate: {
          conversion: '98%',
          rate: '852 / 1,101'
        }
      },
      {
        practicename: 'Practice 2',
        address: '401 E Sonterra Blvd, San Antonio, TX 78258',

        totalSent: {
          item: '850',
          delivered: '68 Not Delivered'
        },
        totalCompleted: {
          item: '800',
          patients: '602 Patients'
        },
        totalPending: {
          item: '850',
          patients: '8002 Patients'
        },
        conversionRate: {
          conversion: '98%',
          rate: '852 / 1,101'
        }
      },
      {
        practicename: 'Practice 3',
        address: '401 E Sonterra Blvd, San Antonio, TX 78258',

        totalSent: {
          item: '850',
          delivered: '68 Not Delivered'
        },
        totalCompleted: {
          item: '800',
          patients: '602 Patients'
        },
        totalPending: {
          item: '850',
          patients: '8002 Patients'
        },
        conversionRate: {
          conversion: '98%',
          rate: '852 / 1,101'
        }
      },
      {
        practicename: 'Practice 4',
        address: '401 E Sonterra Blvd, San Antonio, TX 78258',

        totalSent: {
          item: '850',
          delivered: '68 Not Delivered'
        },
        totalCompleted: {
          item: '800',
          patients: '602 Patients'
        },
        totalPending: {
          item: '850',
          patients: '8002 Patients'
        },
        conversionRate: {
          conversion: '98%',
          rate: '852 / 1,101'
        }
      },
      {
        practicename: 'Practice 5',
        address: '401 E Sonterra Blvd, San Antonio, TX 78258',

        totalSent: {
          item: '850',
          delivered: '68 Not Delivered'
        },
        totalCompleted: {
          item: '800',
          patients: '602 Patients'
        },
        totalPending: {
          item: '850',
          patients: '8002 Patients'
        },
        conversionRate: {
          conversion: '98%',
          rate: '852 / 1,101'
        }
      },
      {
        practicename: 'Practice 6',
        address: '401 E Sonterra Blvd, San Antonio, TX 78258',

        totalSent: {
          item: '850',
          delivered: '68 Not Delivered'
        },
        totalCompleted: {
          item: '800',
          patients: '602 Patients'
        },
        totalPending: {
          item: '850',
          patients: '8002 Patients'
        },
        conversionRate: {
          conversion: '98%',
          rate: '852 / 1,101'
        }
      },



    ];

  }


}
