
import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';

@Component({
  selector: 'app-form-status',
  templateUrl: './form-status.component.html',
  styleUrls: ['./form-status.component.scss']
})
export class FormStatusComponent {
  empty: boolean = false;

  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {
    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      labels: {
        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
        }
      },
      lineWidth: 1,
      lineColor: 'transparent',
    },
    yAxis: {
      gridLineColor: 'rgba(243, 244, 246, 1)',
      labels: {
        format: '{text}', // The $ is literally a dollar unit
        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
          textAlign: 'left'
        }
      },
      title: { text: '' },
    },
    title: { text: '' },
    credits: { enabled: false },
    plotOptions: {
      column: {
        stacking: 'normal'
      }
    },
    series: [


      {
        name: 'Total Not Posted',
        showInLegend: false,
        data: [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,],
        type: 'column',
        color: '#FF7596',
        borderWidth: 0,
        borderRadius: 0,
        pointPadding: 0.07,
      },
      {
        name: 'Total Pending',
        showInLegend: false,
        data: [10, 20, 10, 10, 10, 10, 10, 5, 20, 10, 20, 5],
        type: 'column',
        color: '#FABB87',
        borderWidth: 0,
        borderRadius: 0,
        pointPadding: 0.07,
      },
      {
        name: 'Total Completed',
        showInLegend: false,
        data: [20, 30, 28, 40, 35, 35, 50, 60, 70, 60, 60, 40],
        type: 'column',
        color: '#0ADC8F',
        borderWidth: 0,
        borderRadius: 0,
        pointPadding: 0.07,
      },

    ],
    tooltip: {
      shared: true,
      outside: true,
      useHTML: true,
      backgroundColor: '#fff',
      borderRadius: 10,
      positioner: function (labelWidth, _, point) {
        //console.log(labelWidth, _, point)
        return {
          x: point.plotX - 105,
          y: point.plotY - 115,
        };
      },
      formatter: function (response) {
        let tooltip = '<div class="form_chart_tooltip Jan">';
        tooltip += '<h4>' + this.x + '</h4>';
        tooltip += '<div class = "tooltip-content">';
        tooltip += '<div class="item gross"><p>' + this.points?.[1].series.name + '<span>' + this.points?.[1].y + '</span></p><p>' + this.points?.[0].series.name + '<span>' + this.points?.[0].y + '</span></p><p>' + this.points?.[2].series.name + '<span>' + this.points?.[2].y + '</span></p><p>';
        tooltip += '</div>';
        tooltip += '</div>'
        return tooltip;
      }
    }

  }
}
