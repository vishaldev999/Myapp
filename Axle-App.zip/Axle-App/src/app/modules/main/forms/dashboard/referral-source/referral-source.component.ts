import { Component, OnInit, ViewChild } from '@angular/core';
import * as Highcharts from 'highcharts';
import { Options } from 'highcharts';
@Component({
  selector: 'app-referral-source',
  templateUrl: './referral-source.component.html',
  styleUrls: ['./referral-source.component.scss', './referral-piechart.scss']
})

export class ReferralSourceComponent {

  utsEmployees: any[] = [];
  employeeInsights: any[] = [];
  employeenSightsSidebar: boolean = false;

  // piechart 
  referralSource = [

    { color: '#0ACADC', label: 'tooltip1', referralsSource: 'Facebook', price: '$36,450.23', patients: '89 Patients', referralspercentage: '48%' },
    { color: '#9267B4', label: 'tooltip2', referralsSource: 'Treatment Completed', price: '$36,450.23', patients: '89 Patients', referralspercentage: '48%' },
    { color: '#FF7597', label: 'tooltip3', referralsSource: 'Patient Moved ', price: '$36,450.23', patients: '89 Patients', referralspercentage: '48%' },
    { color: '#FABB87', label: 'tooltip4', referralsSource: 'Insurance', price: '$36,450.23', patients: '89 Patients', referralspercentage: '48%' },
    { color: '#3ADEB2', label: 'tooltip4', referralsSource: 'Internet', price: '$36,450.23', patients: '89 Patients', referralspercentage: '48%' },
    { color: '#04899D', label: 'tooltip4', referralsSource: 'Referred from Other Office', price: '$36,450.23', patients: '289 Patients', referralspercentage: '48%' },

  ];
  tooltip: string = "";
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options;
  updateFlag: any
  chartRef: any

  constructor() {

    this.chartOptions = {
      chart: {
        height: 217,
        width: 217,
        margin: [0, 0, 0, 0],
        spacingTop: 0,
        spacingBottom: 0,
        spacingLeft: 0,
        spacingRight: 0,

        events: {
          load() {
            //console.log(this);
            //this.tooltip.refresh(this.series[0].points[1]); 
          },

        }
      },
      series: [

        {
          innerSize: '60%',
          // showInLegend: true,
          data: [12.5, 12.5, 12.5, 12.5, 12.5, 12.5],
          colors: ['#0ACADC', '#9267B4', '#FF7597', '#FABB87', '#3ADEB2', '#04899D'],
          type: 'pie',
          enableMouseTracking: false,
          borderWidth: 0,
          borderRadius: 0,
          dataLabels: {
            enabled: false
          }
        }
      ],

      title: { text: '' },
      credits: { enabled: false },

    };
  }

  chartCallback: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef = chart;
  };

  removeupdateChart(): void {
    this.tooltip = "";
    this.chartRef.series[0].update({ className: '', },);
    this.updateFlag = false;
  }

  updateChart(val: any, int: any): void {
    let seriesupdate = this.chartRef.series[0]
    this.tooltip = int.label;


    this.updateFlag = false;
  }

  // end


  ngOnInit() {


  }


}