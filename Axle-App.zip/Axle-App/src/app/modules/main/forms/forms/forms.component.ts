import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss']
})
export class FormsComponent {

  constructor(private messageService: MessageService) { }

  profileData: any[] = [];
  tableData: any[] = [];
  isTableData = false;
  isVisible = true;
  isProfile: boolean = false;
  isExpand: boolean = false;
  isEditable: boolean = true;
  showCommlog: boolean = false;
  commLogText: any[] = [];
  isFormModal: boolean = false;
  addForm: string[] = [];
  editForm() {
    this.isEditable = !this.isEditable;
  }

  closeProfile() {
    this.isProfile = false;
    this.isExpand = false;
  }

  expandProfile() {
    this.isExpand = true
  }

  openProfile(selectedItem: any) {

    this.isProfile = true;
    this.isExpand = false;

    this.profileData = [

      {
        name: selectedItem.patientDetails.name,
        picture: selectedItem.patientDetails.picture,
        practiceName: selectedItem.practiceName,
        birth: selectedItem.birth,
      }
    ]

    console.log(selectedItem);

  }

  showCommlogField() {
    this.showCommlog = !this.showCommlog;
  }

  saveCommlog() {
    console.log("showCommlog:-", this.commLogText)
    this.showCommlog = !this.showCommlog;
    this.messageService.add({ key: 'saveCommlog', severity: 'success', summary: 'Commlog added', detail: 'A new commlog was added succesfully.' });
    setTimeout(() => {

      document.body.classList.remove('noScroll');
    }, 2000);
  }


  formRequest() {
    this.isFormModal = false;
    this.messageService.add({ key: 'requestForm', severity: 'success', summary: 'New Forms Requested', detail: '(1) forms were succesfully requested.' });
    setTimeout(() => {

      document.body.classList.remove('noScroll');
    }, 2000);

  }


  openFormModal() {
    this.isFormModal = true;
    document.body.classList.add('noScroll');
  }

  closeFormModal() {
    this.isFormModal = false;
    document.body.classList.remove('noScroll');
  }


  ngOnInit() {
    document.body.classList.add('noScroll');
    setTimeout(() => {
      document.body.classList.remove('noScroll');
      this.isVisible = false;
      this.isTableData = true;

    }, 2000); // 2000 milliseconds = 2 seconds

    this.tableData = [

      {

        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Kai Santos',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '07/04/2015',
        ssn: '••••• 1240',
        formName: 'New Medical History (+3)',
        status: 'Completed',

      },
      {

        patientDetails: {
          picture: '../../../../../assets/aaron.png',
          name: 'Evelyn Lindsay',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Western Union MTCN',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Completed',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/donavon.png',
          name: 'Karina Martinez',
          time: 'Sent on: Aug 06, 2023 at 10:35 AM',
        },

        practiceName: 'Safari-Pedo',
        birth: '1/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Not Posted',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Yahaira Rodriguez',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1965',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History ',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/aaron.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History',
        status: 'Completed',

      },
      {

        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Completed',

      },
      {

        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Completed',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Not Posted',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/donavon.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History ',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History',
        status: 'Completed',

      },
      {

        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Completed',

      },
      {

        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Completed',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Not Posted',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3)',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History ',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History',
        status: 'Completed',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History (+3) ',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History',
        status: 'Pending',

      },

      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History',
        status: 'Pending',

      },
      {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History',
        status: 'Pending',

      }, {
        patientDetails: {
          picture: '../../../../../assets/pf.png',
          name: 'Pedro Becker',
          time: 'Sent on: Jan 12, 2022 at 10:30 AM',
        },

        practiceName: 'Smiling Teeth Clinic',
        birth: '11/25/1985',
        ssn: '••••• 1234',
        formName: 'New Medical History',
        status: 'Pending',

      },

    ];

  }



}


