import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReviewsComponent } from './reviews/reviews.component';
import { ReviewsRoutingModule } from './reviews-routing.module';
import { ReviewsLeftBarComponent } from './reviews/reviews-left-bar/reviews-left-bar.component';
import { ReviewsCountComponent } from './reviews/reviews-count/reviews-count.component';
import { PracticeReviewsComponent } from './reviews/practice-reviews/practice-reviews.component';
import { ReviewsGoogleStatsComponent } from './reviews/reviews-google-stats/reviews-google-stats.component';
import { ReviewsSignupDashboardComponent } from './reviews/reviews-signup-dashboard/reviews-signup-dashboard.component';
import { LoadingBlockComponent } from './reviews/review-loading-block/review-loading-block.component';
import { SharedModule } from './../../../shared/shared.module';



@NgModule({
  declarations: [
    ReviewsComponent,
    ReviewsLeftBarComponent,
    ReviewsCountComponent,
    PracticeReviewsComponent,
    ReviewsGoogleStatsComponent,
    ReviewsSignupDashboardComponent,
    LoadingBlockComponent
  ],
  imports: [
    CommonModule,
    ReviewsRoutingModule,
    SharedModule
  ]
})
export class ReviewsModule { }
