import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';

interface shorting {
  name: string;
}
@Component({
  selector: 'app-reviews-left-bar',
  templateUrl: './reviews-left-bar.component.html',
  styleUrls: ['./reviews-left-bar.component.scss'],
  providers: [MessageService]
})

export class ReviewsLeftBarComponent implements OnInit {
  users: any[] = [];
  selectedUsers!: any;
  filteredUsers: any = [];
  isArchiveModal: boolean = false;
  isComposModal: boolean = false;
  isFilterBlock: boolean = false;
  selectedRatings: any = undefined;

  sortList: any[] = [];
  selectedSorting: any = undefined;

  constructor(private messageService: MessageService) { }


  filterUsers(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    console.log(event)
    filtered = this.users.filter((e: any) => { return e.name.toLowerCase().indexOf(query.toLowerCase()) != -1 });
    console.log(filtered)
    this.filteredUsers = filtered;

  }

  toggleFilter() {
    this.isFilterBlock = !this.isFilterBlock;
  }

  openArchiveModal() {
    this.isArchiveModal = true;
    document.body.classList.add('noScroll');
  }

  closArchiveModal() {
    this.isArchiveModal = false;
    document.body.classList.remove('noScroll');
  }

  openComposModal() {
    this.isComposModal = true;
    document.body.classList.add('noScroll');
  }

  closeComposeModal() {
    this.isComposModal = false;
    document.body.classList.remove('noScroll');
  }

  showArchiveToast() {
    this.messageService.add({ key: 'archiveToast', severity: 'success', summary: 'Review Archived', detail: 'Pedro Becker’s archived succesfully.' });
    setTimeout(() => {
      this.isArchiveModal = false;
      document.body.classList.remove('noScroll');
    }, 2000);
  }

  ratingList = [
    {
      ratingName: '5-star',
    },
    {
      ratingName: '4-star',
    },
    {
      ratingName: '3-star',
    },
    {
      ratingName: '2-star',
    },
    {
      ratingName: '1-star',
    },

  ];

  ngOnInit() {

    this.sortList = [
      { name: 'New - Old' },
      { name: 'Old - New' },
      { name: 'Positive - Negative' },
      { name: 'Negative - Positive' },
    ];

    this.users = [
      {
        name: 'Ashish Kaushik'
      },
      {
        name: 'Nisar'
      },
      {
        name: 'Rachel Etherington'
      },
      {
        name: 'Anurag'
      },
      {
        name: 'Abhishek'
      }
    ];

  }

}
