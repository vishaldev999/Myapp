import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-reviews-google-stats',
  templateUrl: './reviews-google-stats.component.html',
  styleUrls: ['./reviews-google-stats.component.scss']
})
export class ReviewsGoogleStatsComponent {
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {
    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      crosshair: {
        //width: 100,
        color: '#0acbdc1a'
      },
      labels: {
        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
        }
      },
      lineWidth: 1,
      lineColor: 'transparent',
    },
    yAxis: {
      gridLineColor: 'rgba(243, 244, 246, 1)',
      labels: {
        format: '${text}M', // The $ is literally a dollar unit
        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
        }
      },
      title: { text: '' },
    },
    title: { text: '' },
    credits: { enabled: false },
    series: [{
      showInLegend: false,
      name: 'Total Reviews',
      data: [200, 100, 100, 200, 200, 200, 300, 400, 300, 300, 400, 200.100],
      type: 'column',
      color: '#0acadc',
      borderWidth: 0,
      borderRadius: 0,
      pointPadding: 0.07,
    }],
    tooltip: {
      shared: true,
      outside: true,
      useHTML: true,
      backgroundColor: '#fff',
      borderRadius: 10,
      // positioner: function (labelWidth, _, point) {
      //   console.log(labelWidth, _, point)
      //   return {
      //     x: point.plotX - 10,
      //     y: point.plotY - 150,
      //   };
      // },
      formatter: function (response) {
        let tooltip = '<div class="chart_tooltip_googlereview">';
        tooltip += '<h4>' + this.x + ' ' + new Date().getFullYear() + '</h4>';
        tooltip += '<div class = "tooltip-content">';
        var num = response.chart.series
        num.forEach(function (x: any) {
          tooltip += '<div class="item ' + x.name + '"><p><span>' + x.name + '</span></p><h6>' + x.data[0].series.yData[0] + ' </h6></div>';
          tooltip += '<div class="item ' + x.name + '"><p><span>Avg Rating</span></p><h6>' + x.data[0].series.yData[0] + ' <span class="google_img"></span><span class="star full"></span><span class="star full"></span><span class="star full"></span><span class="star empty"></span> </h6></div>';
        });
        tooltip += '</div>';
        tooltip += '</div>'
        return tooltip;
      }
    }
  }
}
