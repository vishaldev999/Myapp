import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewsGoogleStatsComponent } from './reviews-google-stats.component';

describe('ReviewsGoogleStatsComponent', () => {
  let component: ReviewsGoogleStatsComponent;
  let fixture: ComponentFixture<ReviewsGoogleStatsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewsGoogleStatsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReviewsGoogleStatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
