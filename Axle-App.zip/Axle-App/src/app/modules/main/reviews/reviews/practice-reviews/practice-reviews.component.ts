import { Component } from '@angular/core';
@Component({
  selector: 'app-practice-reviews',
  templateUrl: './practice-reviews.component.html',
  styleUrls: ['./practice-reviews.component.scss'],

})
export class PracticeReviewsComponent {
  reviewsPractice: any[] = [];
  reviewDetails: boolean = false;


  ngOnInit() {

    this.reviewsPractice = [
      {
        practicename: 'Practice 1',
        googleReviews: '155',
        axleReviews: '155',
        positiveReviews: '200',
        negativeReviews: '20',
        googleRating: '4.8',
        ratingClass: 'three'
      },
      {
        practicename: 'Practice 2',
        googleReviews: '155',
        axleReviews: '155',
        positiveReviews: '200',
        negativeReviews: '20',
        googleRating: '4.8',
        ratingClass: 'two'
      },
      {
        practicename: 'Practice 3',
        googleReviews: '155',
        axleReviews: '155',
        positiveReviews: '200',
        negativeReviews: '20',
        googleRating: '4.4',
        ratingClass: 'five'
      },
      {
        practicename: 'Practice 4',
        googleReviews: '155',
        axleReviews: '155',
        positiveReviews: '200',
        negativeReviews: '20',
        googleRating: '4.8',
        ratingClass: 'three'
      },
      {
        practicename: 'Practice 5',
        googleReviews: '155',
        axleReviews: '155',
        positiveReviews: '200',
        negativeReviews: '20',
        googleRating: '4.8',
        ratingClass: 'four'
      },
      {
        practicename: 'Practice 6',
        googleReviews: '155',
        axleReviews: '155',
        positiveReviews: '200',
        negativeReviews: '20',
        googleRating: '4.8',
        ratingClass: 'one'
      },


    ];

  }
}
