import { Component } from '@angular/core';

@Component({
  selector: 'app-reviews-signup-dashboard',
  templateUrl: './reviews-signup-dashboard.component.html',
  styleUrls: ['./reviews-signup-dashboard.component.scss']
})
export class ReviewsSignupDashboardComponent {
  tooltipValue: string = "";
  isShowDivIf = false;

  removeDisplayDivIf() {
    this.tooltipValue = '';
  }

  toggleDisplayDivIf(tootipitem: string) {
    if (this.tooltipValue == tootipitem)
      this.tooltipValue = "";
    else
      this.tooltipValue = tootipitem;
  }
}
