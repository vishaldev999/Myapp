import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PracticeReviewsComponent } from './practice-reviews.component';

describe('PracticeReviewsComponent', () => {
  let component: PracticeReviewsComponent;
  let fixture: ComponentFixture<PracticeReviewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PracticeReviewsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PracticeReviewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
