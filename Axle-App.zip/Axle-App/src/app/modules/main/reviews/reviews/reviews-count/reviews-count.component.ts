import { Component } from '@angular/core';

@Component({
  selector: 'app-reviews-count',
  templateUrl: './reviews-count.component.html',
  styleUrls: ['./reviews-count.component.scss']
})
export class ReviewsCountComponent {
  tooltipValue: string = "";
  isShowDivIf = false;

  removeDisplayDivIf() {
    this.tooltipValue = '';
  }

  toggleDisplayDivIf(tootipitem: string) {
    if (this.tooltipValue == tootipitem)
      this.tooltipValue = "";
    else
      this.tooltipValue = tootipitem;
  }
}
