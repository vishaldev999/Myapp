import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewsSignupDashboardComponent } from './reviews-signup-dashboard.component';

describe('ReviewsSignupDashboardComponent', () => {
  let component: ReviewsSignupDashboardComponent;
  let fixture: ComponentFixture<ReviewsSignupDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewsSignupDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReviewsSignupDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
