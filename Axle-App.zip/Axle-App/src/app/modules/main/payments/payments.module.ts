import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PendingComponent } from './pending/pending.component';
import { CompletedComponent } from './completed/completed.component';
import { RecurringComponent } from './recurring/recurring.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PaymentsRoutingModule } from './payments-routing.module';



@NgModule({
  declarations: [
    DashboardComponent,
    PendingComponent,
    CompletedComponent,
    RecurringComponent,
    TransactionComponent
  ],
  imports: [
    CommonModule,
    PaymentsRoutingModule
  ]
})
export class PaymentsModule { }
