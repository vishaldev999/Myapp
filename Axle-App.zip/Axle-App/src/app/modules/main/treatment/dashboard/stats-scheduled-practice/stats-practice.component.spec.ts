import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatsPracticeComponent } from './stats-practice.component';

describe('StatsPracticeComponent', () => {
  let component: StatsPracticeComponent;
  let fixture: ComponentFixture<StatsPracticeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatsPracticeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StatsPracticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
