import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  isTableData = false;
  isVisible = true;

  ngOnInit() {
    document.body.classList.add('noScroll');
    setTimeout(() => {
      document.body.classList.remove('noScroll');
      this.isVisible = false;
      this.isTableData = true;

    }, 2000); // 2000 milliseconds = 2 seconds
  }


}
