import { Component, OnInit, ViewChild } from '@angular/core';
import * as Highcharts from 'highcharts';
import { Options } from 'highcharts';

@Component({
  selector: 'app-uts-employees',
  templateUrl: './uts-employees.component.html',
  styleUrls: ['./uts-employees.component.scss', './utsOutcomesPiechart.scss']
})
export class UtsEmployeesComponent {

  utsEmployees: any[] = [];
  employeeInsights: any[] = [];
  employeenSightsSidebar: boolean = false;


  // piechart 

  utsOutcomes = [

    { color: '#0ACADC', label: 'tooltip1', name: 'No to schedule', practices: '12', adjustedProduction: '$155,000.00' },
    { color: '#9267B4', label: 'tooltip2', name: 'Treatment Completed', practices: '50', adjustedProduction: '$5,000.00' },
    { color: '#FF7597', label: 'tooltip3', name: 'Patient Moved ', practices: '20', adjustedProduction: '$5,000.00' },
    { color: '#FABB87', label: 'tooltip4', name: 'No Insurance', practices: '2', adjustedProduction: '$5,000.00' },


  ];

  tooltip: string = "";

  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options;
  updateFlag: any
  chartRef: any

  constructor() {

    this.chartOptions = {
      chart: {
        height: 233,
        width: 233,
        margin: [0, 0, 0, 0],
        spacingTop: 0,
        spacingBottom: 0,
        spacingLeft: 0,
        spacingRight: 0,

        events: {
          load() {
            //console.log(this);
            //this.tooltip.refresh(this.series[0].points[1]); 
          },

        }
      },
      series: [

        {
          innerSize: '60%',
          // showInLegend: true,
          data: [12.5, 12.5, 12.5, 12.5],
          colors: ['#0ACADC', '#9267B4', '#FF7597', '#FABB87'],
          type: 'pie',
          enableMouseTracking: false,
          borderWidth: 0,
          borderRadius: 0,
          dataLabels: {
            enabled: false
          }
        }
      ],

      title: { text: '' },
      credits: { enabled: false },
      tooltip: {

        className: 'custom-tooltip',
        enabled: true,
        shared: false,
        outside: true,
        useHTML: true,
        formatter: function (response: any) {
          console.log(response);
          console.log(this.color);
          let tooltip = '<div class="chart_tooltip hello ' + this.color + '">';
          // tooltip += '<h4><b></b>Jan 2023</h4>';
          tooltip += '<div class = "tooltip-content">';
          tooltip += '<div class="item gross"><p><span>% of UTS</span></p><h6>60%</h6></div>';
          tooltip += '<div class="item gross"><p><span>UTS</span></p><h6>12</h6></div>';
          tooltip += '</div>';
          tooltip += '</div>'
          return tooltip;
        }

      }
    };
  }

  chartCallback: Highcharts.ChartCallbackFunction = (chart) => {
    this.chartRef = chart;
  };

  removeupdateChart(): void {
    this.tooltip = "";
    this.chartRef.series[0].update(
      {
        className: '',

      },
    );
    this.updateFlag = false;
  }

  updateChart(val: any, int: any): void {
    let seriesupdate = this.chartRef.series[0]
    this.tooltip = int.label;
    if (int.label == 'tooltip1') {
      //      this.tooltip1 = true
      seriesupdate.update(
        {
          className: 'new1',
        },
      );
    }
    if (int.label == 'tooltip2') {
      //    this.tooltip2 = true
      seriesupdate.update(
        {
          className: 'new2',
        },
      );
    }
    if (int.label == 'tooltip3') {
      //  this.tooltip3 = true
      seriesupdate.update(
        {
          className: 'new3',
        },
      );
    }
    if (int.label == 'tooltip4') {
      //this.tooltip4 = true
      seriesupdate.update(
        {
          className: 'new4',
        },
      );
    }
    if (int.label == 'tooltip5') {
      //this.tooltip5 = true
      seriesupdate.update(
        {
          className: 'new5',
        },
      );
    }
    if (int.label == 'tooltip6') {
      //this.tooltip6 = true
      seriesupdate.update(
        {
          className: 'new6',
        },
      );
    }
    if (int.label == 'tooltip7') {
      //this.tooltip7 = true
      seriesupdate.update(
        {
          className: 'new7',
        },
      );
    }
    if (int.label == 'tooltip8') {
      //this.tooltip8 = true
      seriesupdate.update(
        {
          className: 'new8',
        },
      );
    }

    this.updateFlag = false;
  }

  // end


  ngOnInit() {

    // UTS by Employees Table Data
    this.utsEmployees = [

      {
        rankLevel: {
          position: 1,
          rank: "1st",
        },
        details: {
          shortName: 'LL',
          isShortName: false,
          fullName: 'Lois Lane',
          userPic: '../../../../../assets/Pedro.png',
          isUserPic: true
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 2,
          rank: "2nd",
        },
        details: {
          shortName: 'CK',
          isShortName: true,
          fullName: 'Clark Kent',
          userPic: '../../../../../assets/Pedro.png',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 3,
          rank: "3rd",
        },
        details: {
          shortName: 'HG',
          isShortName: false,
          fullName: 'Holly Golightlyt',
          userPic: '../../../../../assets/Pedro.png',
          isUserPic: true
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 4,
          rank: "4th",
        },
        details: {
          shortName: 'LT',
          isShortName: true,
          fullName: 'Liza T',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },

      {
        rankLevel: {
          position: 5,
          rank: "5th",
        },
        details: {
          shortName: 'HH',
          isShortName: true,
          fullName: 'Henry Higgins',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },

      {
        rankLevel: {
          position: 6,
          rank: "6th",
        },
        details: {
          shortName: 'MM',
          isShortName: true,
          fullName: 'Mary Magdalene',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        rankLevel: {
          position: 7,
          rank: "7th",
        },
        details: {
          shortName: 'LL',
          isShortName: true,
          fullName: 'Lois Lane',
          userPic: '../../../../../assets/Pedro.svg',
          isUserPic: false
        },
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },

        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },


    ];
    // end

    // Employee Insights Table Data
    this.employeeInsights = [


      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },

      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
      {
        user: {
          image: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          status: 'Smiling Teeth Clinic',
        },
        procedureCode: 'D432',
        crocedureCost: '+$185.00',
      },
    ];
    // end

  }

  onRightBar() {
    alert();
  }
}
