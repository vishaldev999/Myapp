import { Component } from '@angular/core';


@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.scss']
})
export class PendingComponent {

  pendingTable: any[] = [];

  isTableData = false;
  isVisible = true;


  ngOnInit() {
    document.body.classList.add('noScroll');
    setTimeout(() => {
      document.body.classList.remove('noScroll');
      this.isVisible = false;
      this.isTableData = true;

    }, 2000); // 2000 milliseconds = 2 seconds


    this.pendingTable = [
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {
        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },

      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',

      },

    ];
  }

}