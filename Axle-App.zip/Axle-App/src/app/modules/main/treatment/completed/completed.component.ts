import { Component } from '@angular/core';

@Component({
  selector: 'app-completed',
  templateUrl: './completed.component.html',
  styleUrls: ['./completed.component.scss']
})
export class CompletedComponent {
  completeTable: any[] = [];
  isTableData = false;
  isVisible = true;
  ngOnInit() {
    document.body.classList.add('noScroll');
    setTimeout(() => {
      document.body.classList.remove('noScroll');
      this.isVisible = false;
      this.isTableData = true;

    }, 2000); // 2000 milliseconds = 2 seconds

    this.completeTable = [
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022",

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"

      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },

        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },


        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },
      {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      }, {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      }, {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      }, {

        patientDetails: {
          userPic: '../../../../../assets/Pedro.png',
          name: 'Pedro Becker',
          subTitle: 'Smiling Teeth Clinic',
        },
        insuranceCarrier: 'Delta Dental of New York',
        tooth: '31',
        procedure: 'D0120',
        procedureCost: '$15,500.00',
        diagnosedDate: 'Feb 13, 2022',
        status: 'Unable to Schedule',
        lastContact: "Feb 13, 2022"
      },

    ];

  }
}
