import { Component } from '@angular/core';

@Component({
  selector: 'app-payements',
  templateUrl: './payements.component.html',
  styleUrls: ['./payements.component.scss']
})
export class PayementsComponent {

}
