import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  constructor(private api: CommonService) { }

  isEditUser: boolean = false;
  isRightPanel: boolean = false;

  tableUserData = {
    fullName: 'Test',
    email: 'alerojas1112@gmail.com',
    phoneNumber: '(830) 772-5600',
    practiceAccess: 'Cibolo-Ortho, Cibolo-Pedo, Helotes-Ortho, Helotes-Pedo, Pleasanton-Ortho, Pleasanton-Pedo, Culebra-Ortho, Culebra-Pedo, Sunshine-Ortho, Sunshine-Pedo, Laredo-Pedo, Shaenfield-Ortho, Rittiman-Pedo, Kerrville, Lytle, Rittiman-Ortho, Brooks-Ortho',
  };

  countries: any[] = [];
  tableusers: any[] = [];

  selectedCountries!: any;
  users: any[] = [];
  selectedUsers!: any;
  filteredUsers: any = [];

  cities: any[] = [];
  selectedCities: any[] = [];

  editUserList: any[] = [];
  selectedEditUserList: any = undefined;

  //Edit User
  editUserUsername: string = 'Pedro Becker';
  editUserWorkPhone: string = '(786) 433-6054';
  editUserWorkEmail: string = 'Pedro Becker';

  openEditUserBlock() {
    this.isEditUser = !this.isEditUser;
  }

  closeEditUserBlock() {
    this.isEditUser = false;
  }


  openRightPanel(rightPanelUser: any) {
    this.isRightPanel = true;
    this.tableUserData = rightPanelUser;
  }

  closeRightPanel() {
    this.isRightPanel = false;
  }

  addUsrSlctdPrtcs: any = null;
  addUsrPrtcsList = [
    {
      practiceName: 'Brooks-Ortho'
    },
    {
      practiceName: 'Brooks-Pedo'
    },
    {
      practiceName: 'Cibolo-Ortho'
    },
    {
      practiceName: 'Cibolo-Pedo'
    },
    {
      practiceName: 'Culebra-Ortho'
    },
    {
      practiceName: 'Culebra-Pedo'
    },
    {
      practiceName: 'Helotes-Ortho'
    },
    {
      practiceName: 'Helotes-Pedo'
    },
    {
      practiceName: 'Kerrville'
    },
    {
      practiceName: 'Laredo-Pedo'
    },
    {
      practiceName: 'Lytle'
    },
    {
      practiceName: 'Pleasanton-Ortho'
    },
    {
      practiceName: 'Pleasanton-Pedo'
    },
    {
      practiceName: 'Rittiman-Ortho'
    },
    {
      practiceName: 'Rittiman-Pedo'
    },
    {
      practiceName: 'Safari-Ortho'
    },
    {
      practiceName: 'Safari-Pedo'
    },
    {
      practiceName: 'Shaenfield-Ortho'
    },
    {
      practiceName: 'Shaenfield-Pedo'
    },
    {
      practiceName: 'Sunshine-Ortho'
    },
    {
      practiceName: 'Sunshine-Pedo'
    }
  ];

  filterUsers(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    console.log(event)
    filtered = this.users.filter((e: any) => { return e.name.toLowerCase().indexOf(query.toLowerCase()) != -1 });
    console.log(filtered)
    this.filteredUsers = filtered;
  }

  //Edit User Dropdowns

  //Analytics Dropdown
  editUsrAnltsDrpdn: any = null;
  editUsrAnltsDrpdnList = [
    {
      analyticsName: 'Practice Dashboard'
    },
    {
      analyticsName: 'Provider Dashboard'
    },
    {
      analyticsName: 'Region Dashboard'
    },
    {
      analyticsName: 'Hygiene Dashboard'
    }
  ];

  //Collections Dropdown
  editUsrCltnsDrpdn: any = null;
  editUsrCltnsDrpdnList = [
    {
      collectionsName: 'Dashboard'
    },
    {
      collectionsName: 'Collections'
    }
  ];

  //Eligibility Dropdown
  editUsrElgbltyDrpdn: any;
  editUsrElgbltyDrpdnList: any = [
    {
      key: '0',
      label: 'Dashboard',
      data: 'Dashboard',

    }, {
      key: '1',
      label: 'Pending',
      data: 'Pending',
      children: [
        {
          key: '1-0',
          label: 'Verify Patient',
          data: 'Verify Patient',
        },
        {
          key: '1-1',
          label: 'View Insurance Breakdown',
          data: 'View Insurance Breakdown',
        }
      ]
    },
    {
      key: '2',
      label: 'Verified',
      data: 'Verified',
    }
  ];

  //Engagement Dropdown
  editUsrEngmntDrpdn: any = null;
  editUsrEngmntDrpdnList = [
    {
      engagementName: 'Dashboard'
    },
    {
      engagementName: 'Confirmation Pending'
    },
    {
      engagementName: 'Confirmation Completed'
    },
    {
      engagementName: 'Hygiene Pending'
    },
    {
      engagementName: 'Hygiene Completed'
    }
  ];

  //Forms Dropdown
  editUsrFrmsDrpdn: any = null;
  editUsrFrmsDrpdnList = [
    {
      formsName: 'Dashboard'
    },
    {
      formsName: 'Forms'
    }
  ];

  //Messaging Dropdown
  editUsrMsngngDrpdn: any;
  editUsrMsngngDrpdnList: any = [
    {
      key: '0',
      label: 'Inbox',
      data: 'Inbox',
      children: [
        {
          key: '0-0',
          label: 'Icon Family Dental',
          data: 'Icon Family Dental',
        },
        {
          key: '0-1',
          label: 'Uptown Dallas Dentsitry',
          data: 'Uptown Dallas Dentsitry',
        },
        {
          key: '0-2',
          label: 'Highland Oaks Dental',
          data: 'Highland Oaks Dental',
        }
      ]
    },
    {
      key: '1',
      label: 'Mass SMS',
      data: 'Mass SMS',
    }
  ];

  //Payments Dropdown
  editUsrPmtsDrpdn: any;
  editUsrPmtsDrpdnList: any = [
    {
      key: '0',
      label: 'Dashboard',
      data: 'Dashboard',
    },
    {
      key: '1',
      label: 'Pending',
      data: 'Pending',
    },
    {
      key: '2',
      label: 'Completed',
      data: 'Completed',
    },
    {
      key: '3',
      label: 'Completed',
      data: 'Completed',
    },
    {
      key: '4',
      label: 'Recurring',
      data: 'Recurring',
      children: [
        {
          key: '4-0',
          label: 'Create Plan',
          data: 'Create Plan',
        },
        {
          key: '4-1',
          label: 'Make One-Time Payment',
          data: 'Make One-Time Payment',
        },
        {
          key: '4-2',
          label: 'Update Payment Method',
          data: 'Update Payment Method',
        },
        {
          key: '4-3',
          label: 'Cancel Plan',
          data: 'Cancel Plan',
        }
      ]
    },
    {
      key: '5',
      label: 'Transactions',
      data: 'Transactions',
      children: [
        {
          key: '5-0',
          label: 'Issue Refund',
          data: 'Issue Refund',
        },
        {
          key: '5-1',
          label: 'Send Receipt',
          data: 'Send Receipt',
        },
        {
          key: '5-2',
          label: 'Download Receipt',
          data: 'Download Receipt',
        },
        {
          key: '5-3',
          label: 'Print Receipt',
          data: 'Print Receipt',
        },
        {
          key: '5-4',
          label: 'View Analytics',
          data: 'View Analytics',
        }
      ]
    }
  ];

  //Reviews Dropdown
  editUsrRevwsDrpdn: any;
  editUsrRevwsDrpdnList: any = [
    {
      key: '0',
      label: 'Reviews',
      data: 'Reviews',
      children: [
        {
          key: '0-0',
          label: 'Flag Reviews',
          data: 'Flag Reviews',
        },
        {
          key: '0-1',
          label: 'Reply to Reviews',
          data: 'Reply to Reviews',
        },
        {
          key: '0-2',
          label: 'Archive Reviews',
          data: 'Archive Reviews',
        }
      ]
    }
  ];

  //Treatment Dropdown
  editUsrTrmntDrpdn: any;
  editUsrTrmntDrpdnList: any = [
    {
      key: '0',
      label: 'Dashboard',
      data: 'Dashboard',
      children: [
        {
          key: '0-0',
          label: 'View Employee Insights',
          data: 'View Employee Insights',
        }
      ]
    },
    {
      key: '1',
      label: 'Call List',
      data: 'Call List',
    },
    {
      key: '2',
      label: 'Pending',
      data: 'Pending',
    },
    {
      key: '3',
      label: 'Completed',
      data: 'Completed',
    }
  ];

  //Virtual Terminal Dropdown
  editUsrVtrmnsDrpdn: any = null;
  editUsrVtrmnsDrpdnList = [
    {
      vtrmnlName: 'Virtual Terminal'
    }
  ];

  ngOnInit() {
    this.editUserList = [
      {
        userTypeName: 'Global Admin',
        userTypeClass: 'gadmin'
      },
      {
        userTypeName: 'Admin',
        userTypeClass: 'admin'
      },
      {
        userTypeName: 'Employee',
        userTypeClass: 'employee'
      }
    ];

    this.api.get('Settings/GetUsersAndPracticesList').subscribe(res => {
      this.tableusers = res.data.users;
      console.log(this.tableusers);
    });

    this.users = [
      {
        name: 'Ashish Kaushik'
      },
      {
        name: 'Nisar'
      },
      {
        name: 'Rachel Etherington'
      },
      {
        name: 'Anurag'
      },
      {
        name: 'Abhishek'
      }
    ];

    this.countries = [
      { name: 'Australia', code: 'AU' },
      { name: 'Brazil', code: 'BR' },
      { name: 'China', code: 'CN' },
      { name: 'Egypt', code: 'EG' },
      { name: 'France', code: 'FR' },
      { name: 'Germany', code: 'DE' },
      { name: 'India', code: 'IN' },
      { name: 'Japan', code: 'JP' },
      { name: 'Spain', code: 'ES' },
      { name: 'United States', code: 'US' }
    ];

    this.cities = [
      { name: 'New York', code: 'NY' },
      { name: 'Rome', code: 'RM' },
      { name: 'London', code: 'LDN' },
      { name: 'Istanbul', code: 'IST' },
      { name: 'Paris', code: 'PRS' }
    ];
  }

  getInitials(name: string) {
    var parts = name.split(' ')
    var initials = ''
    for (var i = 0; i < parts.length; i++) {
      if (parts[i].length > 0 && parts[i] !== '') {
        initials += parts[i][0]
      }
    }
    return initials
  }

  getPracticeAccessCount(practiceAccess: string) {
    if (practiceAccess != '') {
      var prcArr = practiceAccess.split(',');
      return '(+' + (prcArr.length - 1) + ')';

    }

    return '';
  }

  public practiceList = [
    {
      practiceName: 'Brooks-Ortho',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Brooks-Pedo',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Cibolo-Ortho',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Cibolo-Pedo',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Culebra-Ortho',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    },
    {
      practiceName: 'Culebra-Pedo',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    }
  ];
}
