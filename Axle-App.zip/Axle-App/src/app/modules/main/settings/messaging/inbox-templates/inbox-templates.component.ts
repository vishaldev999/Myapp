import { Component } from '@angular/core';

@Component({
  selector: 'app-inbox-templates',
  templateUrl: './inbox-templates.component.html',
  styleUrls: ['./inbox-templates.component.scss']
})
export class InboxTemplatesComponent {

}
