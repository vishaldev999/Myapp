import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-automation-templates',
  templateUrl: './automation-templates.component.html',
  styleUrls: ['./automation-templates.component.scss']
})
export class AutomationTemplatesComponent implements OnInit {

  newTmpltMsgBlck: boolean = false;

  //Frequency Response
  sndAftrDngsd: any[] = [];
  selectedSndAftrDngsd: any = undefined;

  //Procedure Code
  prcdrCde: any[] = [];
  selectedPrcdrCde: any = undefined;

  newTmpltBlock() {
    this.newTmpltMsgBlck = true;
    document.body.classList.add('noScroll');
  }

  closeNewTmpltMsgBlck() {
    document.body.classList.remove('noScroll');
  }

  ngOnInit() {

    //Frequency
    this.sndAftrDngsd = [
      { name: '1 day(s)' },
      { name: '2 day(s)' },
      { name: '3 day(s)' },
      { name: '4 day(s)' },
      { name: '5 day(s)' },
      { name: '6 day(s)' },
      { name: '7 day(s)' },
      { name: '8 day(s)' },
      { name: '9 day(s)' },
      { name: '10 day(s)' },
      { name: '11 day(s)' },
      { name: '12 day(s)' },
      { name: '13 day(s)' },
      { name: '14 day(s)' },
      { name: '15 day(s)' },
      { name: '16 day(s)' },
      { name: '17 day(s)' },
      { name: '18 day(s)' },
      { name: '19 day(s)' },
      { name: '20 day(s)' },
      { name: '21 day(s)' },
      { name: '22 day(s)' },
      { name: '23 day(s)' },
      { name: '24 day(s)' },
      { name: '25 day(s)' },
      { name: '26 day(s)' },
      { name: '27 day(s)' },
      { name: '28 day(s)' },
      { name: '29 day(s)' },
      { name: '30 day(s)' }
    ];

    //Procedure Code
    this.prcdrCde = [
      { name: 'D3330' },
      { name: 'D3331' },
      { name: 'D3332' },
      { name: 'D3333' },
      { name: 'D3334' }
    ];

  }
}
