import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmations',
  templateUrl: './confirmations.component.html',
  styleUrls: ['./confirmations.component.scss']
})
export class ConfirmationsComponent implements OnInit {
  startTime: number = 12;
  endTime: number = 12;
  adCnfrmtnBlckStartTime: number = 12;

  newCnfrmtnMsgBlck: boolean = false;

  selectedCmuntnMthd: any = null;
  adCnfrmtnBlckSelectedCmuntnMthd: any = null;

  //Confirmation Response
  cnfrmtnRspnseVrbls: any[] = [];
  selectedCnfrmtnRspnseAdVrbl: any = undefined;

  //Reschedule Response
  rschdleRspnseVrbls: any[] = [];
  selectedRschdleRspnseAdVrbl: any = undefined;

  //Reschedule Response
  dysHrs: any[] = [];
  selectedDysHrs: any = undefined;

  //Reschedule Response
  adCnfrmtnBlckDysHrs: any[] = [];
  adCnfrmtnBlckSelectedDysHrs: any = undefined;

  //Invalid Response
  invldRspnseVrbls: any[] = [];
  selectedInvldRspnseAdVrbl: any = undefined;

  //Frequency Response
  frqncBlck: any[] = [];
  selectedFrqncBlck: any = undefined;

  //Frequency Response
  adCnfrmtnBlckFrqncBlck: any[] = [];
  adCnfrmtnBlckSelectedFrqncBlck: any = undefined;

  newCnfrmtnBlock() {
    this.newCnfrmtnMsgBlck = true;
    document.body.classList.add('noScroll');
  }

  closeNewCnfrmtnMsgBlck() {
    document.body.classList.remove('noScroll');
  }

  //Communication Method
  cmnictnMthdList = [
    {
      name: 'Email',
    },
    {
      name: 'SMS',
    }
  ];

  //Communication Method
  adCnfrmtnBlckCmnictnMthdList = [
    {
      name: 'Email',
    },
    {
      name: 'SMS',
    }
  ];

  ngOnInit() {

    //Confirmation Response
    this.cnfrmtnRspnseVrbls = [
      { name: '*Appt Date & Time*' },
      { name: '*Appt Time*' },
      { name: '*Patient First Name*' },
      { name: '*Patient Full Name*' },
      { name: '*Practice Name*' },
      { name: '*Practice Phone Number*' },
      { name: '*Practice Email Address*' },
      { name: '*STOP*' }
    ];

    //Reschedule Response
    this.rschdleRspnseVrbls = [
      { name: '*Appt Date & Time*' },
      { name: '*Appt Time*' },
      { name: '*Patient First Name*' },
      { name: '*Patient Full Name*' },
      { name: '*Practice Name*' },
      { name: '*Practice Phone Number*' },
      { name: '*Practice Email Address*' },
      { name: '*STOP*' }
    ];

    //Days Or Hours
    this.dysHrs = [
      { name: 'Days' },
      { name: 'Hours' }
    ];

    //Days Or Hours
    this.adCnfrmtnBlckDysHrs = [
      { name: 'Days' },
      { name: 'Hours' }
    ];

    //Frequency
    this.frqncBlck = [
      { name: 'Today' },
      { name: 'Tomorrow' },
      { name: '2 day(s) before' },
      { name: '3 day(s) before' },
      { name: '4 day(s) before' },
      { name: '5 day(s) before' },
      { name: '6 day(s) before' },
      { name: '7 day(s) before' },
      { name: '8 day(s) before' },
      { name: '9 day(s) before' },
      { name: '10 day(s) before' },
      { name: '11 day(s) before' },
      { name: '12 day(s) before' },
      { name: '13 day(s) before' },
      { name: '14 day(s) before' },
      { name: '15 day(s) before' },
      { name: '16 day(s) before' },
      { name: '17 day(s) before' },
      { name: '18 day(s) before' },
      { name: '19 day(s) before' },
      { name: '20 day(s) before' },
      { name: '21 day(s) before' },
      { name: '22 day(s) before' },
      { name: '23 day(s) before' },
      { name: '24 day(s) before' },
      { name: '25 day(s) before' },
      { name: '26 day(s) before' },
      { name: '27 day(s) before' },
      { name: '28 day(s) before' },
      { name: '29 day(s) before' }
    ];

    //Frequency
    this.adCnfrmtnBlckFrqncBlck = [
      { name: 'Today' },
      { name: 'Tomorrow' },
      { name: '2 day(s) before' },
      { name: '3 day(s) before' },
      { name: '4 day(s) before' },
      { name: '5 day(s) before' },
      { name: '6 day(s) before' },
      { name: '7 day(s) before' },
      { name: '8 day(s) before' },
      { name: '9 day(s) before' },
      { name: '10 day(s) before' },
      { name: '11 day(s) before' },
      { name: '12 day(s) before' },
      { name: '13 day(s) before' },
      { name: '14 day(s) before' },
      { name: '15 day(s) before' },
      { name: '16 day(s) before' },
      { name: '17 day(s) before' },
      { name: '18 day(s) before' },
      { name: '19 day(s) before' },
      { name: '20 day(s) before' },
      { name: '21 day(s) before' },
      { name: '22 day(s) before' },
      { name: '23 day(s) before' },
      { name: '24 day(s) before' },
      { name: '25 day(s) before' },
      { name: '26 day(s) before' },
      { name: '27 day(s) before' },
      { name: '28 day(s) before' },
      { name: '29 day(s) before' }
    ];

    //Invalid Response
    this.invldRspnseVrbls = [
      { name: '*Appt Date & Time*' },
      { name: '*Appt Time*' },
      { name: '*Patient First Name*' },
      { name: '*Patient Full Name*' },
      { name: '*Practice Name*' },
      { name: '*Practice Phone Number*' },
      { name: '*Practice Email Address*' },
      { name: '*STOP*' }
    ];

  }
}
