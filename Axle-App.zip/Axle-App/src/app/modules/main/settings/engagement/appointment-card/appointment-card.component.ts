import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-card',
  templateUrl: './appointment-card.component.html',
  styleUrls: ['./appointment-card.component.scss']
})
export class AppointmentCardComponent implements OnInit {


  //Confirmation Response
  apntmntCnfrmtnsVrbls: any[] = [];
  selectedApntmntCnfrmtnsVrbls: any = undefined;

  ngOnInit() {

    //Confirmation Response
    this.apntmntCnfrmtnsVrbls = [
      { name: '*Appt Date & Time*' },
      { name: '*Appt Time*' },
      { name: '*Patient First Name*' },
      { name: '*Patient Full Name*' },
      { name: '*Practice Name*' },
      { name: '*Practice Phone Number*' },
      { name: '*Practice Email Address*' },
      { name: '*STOP*' }
    ];

  }
}
