import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-practices',
  templateUrl: './practices.component.html',
  styleUrls: ['./practices.component.scss']
})

export class PracticesComponent implements OnInit {
  constructor(private api: CommonService) { }

  isEditBlock: boolean = false;
  isRightPanel: boolean = false;

  isEditBrand: boolean = false;
  isEditAppearance: boolean = false;

  isEditCard: boolean = false;

  brandAppearanceHeading: string = 'Brand Details';

  editstates: any[] = [];
  selectedEditState: any = undefined;

  //Edit Appearance & Socials
  editAppearanceInsta: string = '@iconfamilydental';
  editAppearanceTwitter: string = '@iconfamilydental';
  editAppearanceIn: string = '@iconfamilydental';
  editAppearanceFb: string = '@iconfamilydental';

  cardEditNameField: string = 'Pedro Becker';

  tablePrctcData = {
    practiceName: 'Test',
    practiceColor: 'Test',
    organization: 'Test',
    officeEmail: 'Test',
    phoneNumber: 'Test',
    practiceAddress: 'Test',
    state: 'Test',
    zipCode: 'Test',
    city: 'Test',
  };

  tablepractices: any[] = [];

  users: any[] = [];
  selectedUsers!: any;
  filteredUsers: any = [];


  openRightPanel(rightPanelUser: any) {
    this.isRightPanel = true;
    this.tablePrctcData = rightPanelUser;
  }

  closeRightPanel() {
    this.isRightPanel = false;
  }

  openEditBlock() {
    this.isEditBlock = true;
  }

  closeEditBlock() {
    this.isEditBlock = false;
  }

  openEditCard() {
    this.isEditCard = true;
  }

  closeEditCard() {
    this.isEditCard = false;
  }

  openEditBrand() {
    this.brandAppearanceHeading = 'Upload Logo';
    this.isEditBrand = true;
  }

  closeEditBrand() {
    this.brandAppearanceHeading = 'Brand Details';
    this.isEditBrand = false;
  }

  openEditAppearance() {
    this.brandAppearanceHeading = 'Appearance & Socials';
    this.isEditAppearance = true;
  }

  closeEditAppearance() {
    this.brandAppearanceHeading = 'Brand Details';
    this.isEditAppearance = false;
  }

  ngOnInit() {
    this.api.get('Settings/GetUsersAndPracticesList').subscribe(res => {
      this.tablepractices = res.data.practices;
    });

    this.users = [
      {
        name: 'Ashish Kaushik'
      },
      {
        name: 'Nisar'
      },
      {
        name: 'Rachel Etherington'
      },
      {
        name: 'Anurag'
      },
      {
        name: 'Abhishek'
      }
    ];

    this.editstates = [
      { name: 'Australia', code: 'AU' },
      { name: 'Brazil', code: 'BR' },
      { name: 'China', code: 'CN' },
      { name: 'Egypt', code: 'EG' },
      { name: 'France', code: 'FR' },
      { name: 'Germany', code: 'DE' },
      { name: 'India', code: 'IN' },
      { name: 'Japan', code: 'JP' },
      { name: 'Spain', code: 'ES' },
      { name: 'United States', code: 'US' }
    ];
  }
}