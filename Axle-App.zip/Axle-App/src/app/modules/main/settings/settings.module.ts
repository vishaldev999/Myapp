import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersComponent } from './users/users.component';
import { PracticesComponent } from './practices/practices.component';
import { EligibilityComponent } from './eligibility/eligibility.component';
import { EngagementComponent } from './engagement/engagement.component';
import { FormsComponent } from './forms/forms.component';
import { GoalsComponent } from './goals/goals.component';
import { MessagingComponent } from './messaging/messaging.component';
import { PayementsComponent } from './payements/payements.component';
import { ReviewsComponent } from './reviews/reviews.component';
import { SchedulingComponent } from './scheduling/scheduling.component';
import { TreatmentComponent } from './treatment/treatment.component';
import { SettingsRoutingModule } from './settings-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { ConfirmationsComponent } from './engagement/confirmations/confirmations.component';
import { RemindersComponent } from './engagement/reminders/reminders.component';
import { AppointmentCardComponent } from './engagement/appointment-card/appointment-card.component';
import { AutomationTemplatesComponent } from './messaging/automation-templates/automation-templates.component';
import { InboxTemplatesComponent } from './messaging/inbox-templates/inbox-templates.component';
import { CampaignsComponent } from './messaging/campaigns/campaigns.component';



@NgModule({
  declarations: [
    UsersComponent,
    PracticesComponent,
    EligibilityComponent,
    EngagementComponent,
    FormsComponent,
    GoalsComponent,
    MessagingComponent,
    PayementsComponent,
    ReviewsComponent,
    SchedulingComponent,
    TreatmentComponent,
    ConfirmationsComponent,
    RemindersComponent,
    AppointmentCardComponent,
    AutomationTemplatesComponent,
    InboxTemplatesComponent,
    CampaignsComponent
  ],
  imports: [
    CommonModule,
    SettingsRoutingModule,
    SharedModule,
    HttpClientModule
  ],
  providers: [
    HttpClient,
    CommonService
  ]
})
export class SettingsModule { }
