import { Component, ViewChild } from '@angular/core';
import { SubTopbarDirective } from './sub-topbar.directive';
import { MenuClass } from './menu';
import { filterDeep } from 'deepdash-es/standalone';
import { CurrentMenuService } from '../shared/services/current-menu.service';
import { SubTopbarComponent } from './sub-topbar/sub-topbar.component';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent {
  @ViewChild(SubTopbarDirective, { static: true }) appSubTopbar!: SubTopbarDirective;

  navValue: string = ""
  fullwidth: boolean = false;
  menuId: string = '';

  constructor(private currentMenuService: CurrentMenuService) { }

  ngOnInit(): void {
    let menulist = new MenuClass().menuList;
    this.currentMenuService.getMenu.subscribe(menuid => {
      let menus = filterDeep(menulist, (value) => {
        return value.id.toUpperCase() == menuid.toUpperCase();
      }, { childrenPath: ['submenu'] });
      if (menus.length > 0) {
        this.loadComponent(menus[0]?.submenu[0]?.subtopbar)
      }
    });

  }

  toggleFullwidth(fullwidth: boolean) {
    this.fullwidth = fullwidth;
  }

  menuSelect(menuid: string) {
    this.menuId = menuid;
  }

  expandDropdown(navitem: string) {
    if (this.navValue == navitem)
      this.navValue = "";
    else
      this.navValue = navitem;
  }


  loadComponent(component: any) {
    component = !component ? SubTopbarComponent : component
    const viewContainerRef = this.appSubTopbar.viewContainerRef;
    viewContainerRef.clear();
    viewContainerRef.createComponent(component);

  }
}
