import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-topbar-with-filter',
  templateUrl: './sub-topbar-with-filter.component.html',
  styleUrls: ['./sub-topbar-with-filter.component.scss']
})
export class SubTopbarWithFilterComponent implements OnInit {
  users: any[] = [];
  selectedUsers!: any;
  filteredUsers: any = [];

  cities: any[] = [];
  selectedCities: any[] = [];

  isAddUserBlock: boolean = false;

  userType: any[] = [];
  selectedUserType: any = undefined;

  addUsrSlctdPrtcs: any = null;
  addUsrPrtcsList = [
    {
      practiceName: 'Brooks-Ortho'
    },
    {
      practiceName: 'Brooks-Pedo'
    },
    {
      practiceName: 'Cibolo-Ortho'
    },
    {
      practiceName: 'Cibolo-Pedo'
    },
    {
      practiceName: 'Culebra-Ortho'
    },
    {
      practiceName: 'Culebra-Pedo'
    },
    {
      practiceName: 'Helotes-Ortho'
    },
    {
      practiceName: 'Helotes-Pedo'
    },
    {
      practiceName: 'Kerrville'
    },
    {
      practiceName: 'Laredo-Pedo'
    },
    {
      practiceName: 'Lytle'
    },
    {
      practiceName: 'Pleasanton-Ortho'
    },
    {
      practiceName: 'Pleasanton-Pedo'
    },
    {
      practiceName: 'Rittiman-Ortho'
    },
    {
      practiceName: 'Rittiman-Pedo'
    },
    {
      practiceName: 'Safari-Ortho'
    },
    {
      practiceName: 'Safari-Pedo'
    },
    {
      practiceName: 'Shaenfield-Ortho'
    },
    {
      practiceName: 'Shaenfield-Pedo'
    },
    {
      practiceName: 'Sunshine-Ortho'
    },
    {
      practiceName: 'Sunshine-Pedo'
    }
  ];

  //Popup Fields
  userFullname: string = '';
  userEmailAddress: string = '';
  userMobilePhone: string = '';

  filterUsers(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    console.log(event)
    filtered = this.users.filter((e: any) => { return e.name.toLowerCase().indexOf(query.toLowerCase()) != -1 });
    console.log(filtered)
    this.filteredUsers = filtered;
  }

  //Add User Dropdowns

  //Analytics Dropdown
  addUsrAnltsDrpdn: any = null;
  addUsrAnltsDrpdnList = [
    {
      analyticsName: 'Practice Dashboard'
    },
    {
      analyticsName: 'Provider Dashboard'
    },
    {
      analyticsName: 'Region Dashboard'
    },
    {
      analyticsName: 'Hygiene Dashboard'
    }
  ];

  //Collections Dropdown
  addUsrCltnsDrpdn: any = null;
  addUsrCltnsDrpdnList = [
    {
      collectionsName: 'Dashboard'
    },
    {
      collectionsName: 'Collections'
    }
  ];

  //Eligibility Dropdown
  addUsrElgbltyDrpdn: any;
  addUsrElgbltyDrpdnList: any = [
    {
      key: '0',
      label: 'Dashboard',
      data: 'Dashboard',

    }, {
      key: '1',
      label: 'Pending',
      data: 'Pending',
      children: [
        {
          key: '1-0',
          label: 'Verify Patient',
          data: 'Verify Patient',
        },
        {
          key: '1-1',
          label: 'View Insurance Breakdown',
          data: 'View Insurance Breakdown',
        }
      ]
    },
    {
      key: '2',
      label: 'Verified',
      data: 'Verified',
    }
  ];

  //Engagement Dropdown
  addUsrEngmntDrpdn: any = null;
  addUsrEngmntDrpdnList = [
    {
      engagementName: 'Dashboard'
    },
    {
      engagementName: 'Confirmation Pending'
    },
    {
      engagementName: 'Confirmation Completed'
    },
    {
      engagementName: 'Hygiene Pending'
    },
    {
      engagementName: 'Hygiene Completed'
    }
  ];

  //Forms Dropdown
  addUsrFrmsDrpdn: any = null;
  addUsrFrmsDrpdnList = [
    {
      formsName: 'Dashboard'
    },
    {
      formsName: 'Forms'
    }
  ];

  //Messaging Dropdown
  addUsrMsngngDrpdn: any;
  addUsrMsngngDrpdnList: any = [
    {
      key: '0',
      label: 'Inbox',
      data: 'Inbox',
      children: [
        {
          key: '0-0',
          label: 'Icon Family Dental',
          data: 'Icon Family Dental',
        },
        {
          key: '0-1',
          label: 'Uptown Dallas Dentsitry',
          data: 'Uptown Dallas Dentsitry',
        },
        {
          key: '0-2',
          label: 'Highland Oaks Dental',
          data: 'Highland Oaks Dental',
        }
      ]
    },
    {
      key: '1',
      label: 'Mass SMS',
      data: 'Mass SMS',
    }
  ];

  //Payments Dropdown
  addUsrPmtsDrpdn: any;
  addUsrPmtsDrpdnList: any = [
    {
      key: '0',
      label: 'Dashboard',
      data: 'Dashboard',
    },
    {
      key: '1',
      label: 'Pending',
      data: 'Pending',
    },
    {
      key: '2',
      label: 'Completed',
      data: 'Completed',
    },
    {
      key: '3',
      label: 'Completed',
      data: 'Completed',
    },
    {
      key: '4',
      label: 'Recurring',
      data: 'Recurring',
      children: [
        {
          key: '4-0',
          label: 'Create Plan',
          data: 'Create Plan',
        },
        {
          key: '4-1',
          label: 'Make One-Time Payment',
          data: 'Make One-Time Payment',
        },
        {
          key: '4-2',
          label: 'Update Payment Method',
          data: 'Update Payment Method',
        },
        {
          key: '4-3',
          label: 'Cancel Plan',
          data: 'Cancel Plan',
        }
      ]
    },
    {
      key: '5',
      label: 'Transactions',
      data: 'Transactions',
      children: [
        {
          key: '5-0',
          label: 'Issue Refund',
          data: 'Issue Refund',
        },
        {
          key: '5-1',
          label: 'Send Receipt',
          data: 'Send Receipt',
        },
        {
          key: '5-2',
          label: 'Download Receipt',
          data: 'Download Receipt',
        },
        {
          key: '5-3',
          label: 'Print Receipt',
          data: 'Print Receipt',
        },
        {
          key: '5-4',
          label: 'View Analytics',
          data: 'View Analytics',
        }
      ]
    }
  ];

  //Reviews Dropdown
  addUsrRevwsDrpdn: any;
  addUsrRevwsDrpdnList: any = [
    {
      key: '0',
      label: 'Reviews',
      data: 'Reviews',
      children: [
        {
          key: '0-0',
          label: 'Flag Reviews',
          data: 'Flag Reviews',
        },
        {
          key: '0-1',
          label: 'Reply to Reviews',
          data: 'Reply to Reviews',
        },
        {
          key: '0-2',
          label: 'Archive Reviews',
          data: 'Archive Reviews',
        }
      ]
    }
  ];

  //Treatment Dropdown
  addUsrTrmntDrpdn: any;
  addUsrTrmntDrpdnList: any = [
    {
      key: '0',
      label: 'Dashboard',
      data: 'Dashboard',
      children: [
        {
          key: '0-0',
          label: 'View Employee Insights',
          data: 'View Employee Insights',
        }
      ]
    },
    {
      key: '1',
      label: 'Call List',
      data: 'Call List',
    },
    {
      key: '2',
      label: 'Pending',
      data: 'Pending',
    },
    {
      key: '3',
      label: 'Completed',
      data: 'Completed',
    }
  ];

  //Virtual Terminal Dropdown
  addUsrVtrmnsDrpdn: any = null;
  addUsrVtrmnsDrpdnList = [
    {
      vtrmnlName: 'Virtual Terminal'
    }
  ];

  ngOnInit() {
    this.users = [
      {
        name: 'Ashish Kaushik'
      },
      {
        name: 'Nisar'
      },
      {
        name: 'Rachel Etherington'
      },
      {
        name: 'Anurag'
      },
      {
        name: 'Abhishek'
      }
    ];

    this.userType = [
      {
        userTypeName: 'Global Admin',
        userTypeClass: 'gadmin'
      },
      {
        userTypeName: 'Admin',
        userTypeClass: 'admin'
      },
      {
        userTypeName: 'Employee',
        userTypeClass: 'employee'
      }
    ];

    this.cities = [
      { name: 'New York', code: 'NY' },
      { name: 'Rome', code: 'RM' },
      { name: 'London', code: 'LDN' },
      { name: 'Istanbul', code: 'IST' },
      { name: 'Paris', code: 'PRS' }
    ];
  }

  openAddUserBlock() {
    this.isAddUserBlock = !this.isAddUserBlock;
    document.body.classList.add('noScroll');
  }

  closeAddUserBlock() {
    this.isAddUserBlock = false;
    document.body.classList.remove('noScroll');
  }
}
