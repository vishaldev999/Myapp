import { Component, Input, OnInit } from '@angular/core';
import { CurrentMenuService } from 'src/app/shared/services/current-menu.service';
import { MenuClass } from '../menu';
import { filterDeep } from 'deepdash-es/standalone';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss']
})
export class TopbarComponent implements OnInit {

  isProfileBlock: boolean = false;
  isEditUserBlock: boolean = false;

  userEditForm!: FormGroup;

  menuid: string = ''
  parentMenuId: string = '';
  menuList: any;

  constructor(private router: Router, private currentMenuService: CurrentMenuService) {
    const urlTree = this.router.parseUrl(this.router.url);
    const urlWithoutParams = urlTree.root.children['primary'].segments.map(it => it.path).join('/')
    let menulist = new MenuClass().menuList;
    let menus = filterDeep(menulist, (value) => {
      return value.url.toUpperCase() == urlWithoutParams.toUpperCase();
    }, { childrenPath: ['submenu'] }
    );
    if (!!menus) {
      this.parentMenuId = menus[0]?.id;
      this.menuid = menus[0]?.submenu[0]?.id;
      this.currentMenuService.setParent(this.parentMenuId);
      this.currentMenuService.setMenu(this.menuid);
    }
  }

  ngOnInit(): void {
    this.getMenu();
  }

  getMenu() {
    this.currentMenuService.getMenu.subscribe((data: any) => {
      this.menuid = data;
    });

    this.currentMenuService.getParentMenu.subscribe((data: any) => {
      this.parentMenuId = data;
      this.menuList = new MenuClass().menuList.
        filter((e: any) => { return e.id == this.parentMenuId })[0]?.submenu;
    });
  }

  profileBlock() {
    this.isProfileBlock = !this.isProfileBlock;
    document.body.classList.add('noScroll');
  }

  closeProfileBlock() {
    this.isProfileBlock = false;
    document.body.classList.remove('noScroll');
  }

  editUserBlock() {
    this.isProfileBlock = false;
    this.isEditUserBlock = true;
    document.body.classList.add('noScroll');
  }

  closeEditUserBlock() {
    this.isEditUserBlock = false;
    document.body.classList.remove('noScroll');
  }

}
