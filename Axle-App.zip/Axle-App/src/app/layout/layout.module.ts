import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './layout.component';
import { RightSidebarComponent } from './right-sidebar/right-sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { SubTopbarComponent } from './sub-topbar/sub-topbar.component';
import { TopbarComponent } from './topbar/topbar.component';
import { LeftSidebarComponent } from './left-sidebar/left-sidebar.component';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { SubTopbarWithFilterComponent } from './sub-topbar-with-filter/sub-topbar-with-filter.component';
import { SubTopbarDirective } from './sub-topbar.directive';
import { SettingPracticeSubTopbarComponent } from './setting-practice-sub-topbar/setting-practice-sub-topbar.component';
import { EligibilitySubTopbarComponent } from './eligibility-sub-topbar/eligibility-sub-topbar.component';



@NgModule({
  declarations: [
    LayoutComponent,
    RightSidebarComponent,
    FooterComponent,
    SubTopbarComponent,
    TopbarComponent,
    LeftSidebarComponent,
    SubTopbarWithFilterComponent,
    SubTopbarDirective,
    SettingPracticeSubTopbarComponent,
    EligibilitySubTopbarComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule
  ]
})
export class LayoutModule { }
