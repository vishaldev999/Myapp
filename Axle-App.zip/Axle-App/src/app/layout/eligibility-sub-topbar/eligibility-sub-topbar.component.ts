import { Component } from '@angular/core';

@Component({
  selector: 'app-eligibility-sub-topbar',
  templateUrl: './eligibility-sub-topbar.component.html',
  styleUrls: ['./eligibility-sub-topbar.component.scss']
})
export class EligibilitySubTopbarComponent {
  public selectedPractice: any = {};
  practiceList = [
    {
      practiceName: 'Brooks-Ortho',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Brooks-Pedo',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Cibolo-Ortho',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Cibolo-Pedo',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Culebra-Ortho',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    },
    {
      practiceName: 'Culebra-Pedo',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    }
  ];
}
