import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

const API_URL = 'http://192.168.1.150/axle-api-refined-video';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  [x: string]: any;

  constructor(private http: HttpClient) { }

  public get(url: any): Observable<any> {
    var header = {
      headers: new HttpHeaders().set(
        'Authorization',
        'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImN0eSI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6Imd1cnByZWV0QGJlY2tlcmFsbGlhbmNlLmNvbSIsIm5iZiI6MTY5MDI1OTc0MywiZXhwIjoxNjkwMjYwMzQzLCJpYXQiOjE2OTAyNTk3NDN9.KPbch-RvjEVmzcb5DiU4L66I_43WIexYW9Zpv_45VzE'
      ),
    };
    return this.http.get(API_URL + '/api/' + url, header).pipe(map(res => res));
  }

  public post(url: any): Observable<any> {
    var header = {
      headers: new HttpHeaders().set(
        'Authorization',
        'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImN0eSI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6Imd1cnByZWV0QGJlY2tlcmFsbGlhbmNlLmNvbSIsIm5iZiI6MTY4OTc0MTM0NCwiZXhwIjoxNjg5NzQxOTQ0LCJpYXQiOjE2ODk3NDEzNDR9.23C_tpvKlaokplc68PWmP30Sx9x1AegxanIFue_SK-M'
      ),
    };
    return this.http.post(API_URL + '/api/' + url, header).pipe(map(res => res));
  }
}
