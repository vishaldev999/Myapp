import { Component } from '@angular/core';

@Component({
  selector: 'app-virtual-terminal',
  templateUrl: './virtual-terminal.component.html',
  styleUrls: ['./virtual-terminal.component.scss']
})
export class VirtualTerminalComponent {
  block = 1;

  isTerminal: boolean = false;
  isNewCard: boolean = false;

  addNewCard() {
    this.isNewCard = true;
  }

  closeNewCard() {
    this.isNewCard = false;
  }

  openTerminal() {
    this.isTerminal = !this.isTerminal;
    document.body.classList.add('noScroll');
  }

  closeTerminal() {
    this.isTerminal = false;
    document.body.classList.remove('noScroll');
    this.block = 1;
  }

  practices: any=[];
  transactions: any=[];
  patients: any[] = [];
  transactiontype: any[] = [];
  cards: any[] = [];

  selectedPractice!: any;
  selectedTransaction!: any;
  selectedPatients!: any;
  selectedTransactiontype!: any;
  filteredPatients: any = [];
  selectedCards!: any;

  ngOnInit() {
      this.practices = [
          {name:'Brooks-Ortho'},
          {name:'Brooks-Ortho'},
          {name:'Brooks-Pedo'},
          {name:'Cibolo-Ortho'},
          {name:'Cibolo-Pedo'},
          {name:'Culebra-Ortho'},
          {name:'Culebra-Pedo'},
          {name:'Helotes-Ortho'},
          {name:'Helotes-Pedo'},
          {name:'Kerrville'},
          {name:'Laredo-Pedo'},
          {name:'Lytle'},
          {name:'Pleasanton-Ortho'},
          {name:'Pleasanton-Pedo'},
          {name:'Rittiman-Ortho'},
          {name:'Rittiman-Pedo'},
          {name:'Safari-Ortho'},
          {name:'Safari-Pedo'},
          {name:'Shaenfield-Ortho'},
          {name:'Shaenfield-Pedo'},
          {name:'Sunshine-Ortho'},
          {name:'Sunshine-Pedo'},
      ];

      this.transactions = [
        {name:'Patient Payment'},
        {name:'Insurance Payment'}
      ];

      this.transactiontype = [
        {name:'Insurance Copay'},
        {name:'Other'}
      ];

     this.patients = [
       {
        name:'Ashish Kaushik',
        dob: '03/16/1995',
        cardno: '••••• 1234'
      },
      {
        name:'Nisar',
        dob: '03/16/1995',
        cardno: '••••• 1234'
      },
      {
        name:'Rachel Etherington',
        dob: '03/16/1995',
        cardno: '••••• 1234'
      },
      {
        name:'Anurag',
        dob: '03/16/1995',
        cardno: '••••• 1234'
      },
      {
        name:'Abhishek',
        dob: '03/16/1995',
        cardno: '••••• 1234'
      }
    ];

    this.cards = [
      {
        cardimage: '../../assets/amexCard.svg',
        cardname: 'American Express',
        cardnumber: '••• 1234'
    },
    {
        cardimage: '../../assets/visaCard.svg',
        cardname: 'Visa',
        cardnumber: '••• 1234'
    },
    {
        cardimage: '../../assets/visaCard.svg',
        cardname: 'Visa',
        cardnumber: '••• 1234'
    },
    {
        cardimage: '../../assets/defaultCard.svg',
        cardname: '',
        cardnumber: '',
        default:1
    }
  ];
  }

  filterPatients(event:any) {
    let filtered: any[] = [];
        let query = event.query;
        console.log(event)
        filtered = this.patients.filter((e:any)=>{ return e.name.toLowerCase().indexOf(query.toLowerCase())!=-1});
        console.log(filtered)
        this.filteredPatients = filtered;
  }

  //Back
  backToPrevStep() {
    this.block = this.block -1;
  }
  
  //Steps click
  virtualPayment(){
    this.block = 2;
  }
  nextStep2(){
    this.block = 3;
  }
}