export class Token {
  token!: string;
  refreshToken!: string;
  refreshTokenExpiryTime!: Date;
  locationGets!: LocationsGet[];
}


export interface LocationsGet{
  id: number;
  centerLocationId : number;
  centerLocationName : string;
  isDefaut : boolean
}