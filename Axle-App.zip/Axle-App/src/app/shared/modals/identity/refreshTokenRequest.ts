export interface RefreshTokenRequest {
    token: string;
    refreshToken: string;
}