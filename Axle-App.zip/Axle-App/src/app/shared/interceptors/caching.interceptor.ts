import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, of, tap } from "rxjs";

@Injectable()
export class CachingInterceptor implements HttpInterceptor{

  private _cache :Map<string,HttpResponse<any>> = new Map()

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if(!req.headers.get('is-cached'))
      return next.handle(req);

    const cacheRes: HttpResponse<any> | undefined = this._cache.get(req.urlWithParams);
    if(cacheRes){
      return of(cacheRes.clone());
    }
    else{
      return next.handle(req).pipe(
        tap<HttpEvent<any>>((httpEvent: HttpEvent<any>) => {
          if (httpEvent instanceof HttpResponse) {
            this._cache.set(req.urlWithParams, httpEvent.clone());
          }
          return !!cacheRes ? cacheRes : httpEvent;
        })
      );
    }
  }

}
