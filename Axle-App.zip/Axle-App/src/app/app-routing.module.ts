import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';
import { ErrorNotFoundComponent } from './modules/error/error-not-found/error-not-found.component';
import { AuthGuard } from './shared/guards/auth.guard';

const routes: Routes = [
  {
    path: '', component: LayoutComponent, //canActivate: [AuthGuard],
    children: [
      { path: 'analytics', loadChildren: () => import('./modules/main/analytics/analytics.module').then(m => m.AnalyticsModule) },
      { path: 'collection', loadChildren: () => import('./modules/main/collection/collection.module').then(m => m.CollectionModule) },
      { path: 'eligiblity', loadChildren: () => import('./modules/main/eligiblity/eligiblity.module').then(m => m.EligiblityModule) },
      { path: 'engagement', loadChildren: () => import('./modules/main/engagement/engagement.module').then(m => m.EngagementModule) },
      { path: 'forms', loadChildren: () => import('./modules/main/forms/forms.module').then(m => m.FormsModule) },
      { path: 'messaging', loadChildren: () => import('./modules/main/messaging/messaging.module').then(m => m.MessagingModule) },
      { path: 'payments', loadChildren: () => import('./modules/main/payments/payments.module').then(m => m.PaymentsModule) },
      { path: 'reviews', loadChildren: () => import('./modules/main/reviews/reviews.module').then(m => m.ReviewsModule) },
      { path: 'treatment', loadChildren: () => import('./modules/main/treatment/treatment.module').then(m => m.TreatmentModule) },
      { path: 'patients', loadChildren: () => import('./modules/main/patients/patitnts-routing.module').then(m => m.PatientsRoutingModule) },
      { path: 'schedule', loadChildren: () => import('./modules/main/schedule/schedule.module').then(m => m.ScheduleModule) },
      { path: 'settings', loadChildren: () => import('./modules/main/settings/settings.module').then(m => m.SettingsModule) },
      { path: '', redirectTo: 'analytics', pathMatch: 'full' },
      { path: 'help-center', loadChildren: () => import('./modules/main/help-center/help-center.module').then(m => m.HelpCenterModule) },
      { path: 'road-map', loadChildren: () => import('./modules/main/road-map/road-map.module').then(m => m.RoadMapModule) }
    ]
  },
  { path: 'auth', loadChildren: () => import('./modules/auth/auth.module').then(m => m.AuthModule) },
  { path: 'not-found', component: ErrorNotFoundComponent },
  { path: '**', redirectTo: 'not-found', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }